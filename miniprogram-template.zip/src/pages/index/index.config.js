export default {
  navigationBarTitleText: '首页',
  disableScroll: true
}
