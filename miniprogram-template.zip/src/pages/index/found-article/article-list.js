'use strict'
export default [
  {
    title: '半持久微化妆是一种美，是一种态度，更是一种艺术',
    content: [
      {
        img: 'http://mcdn.jfshare.com/image/default/B8BB5BE38C044607B76CEE98171DF1D8-6-2.jpg?x-oss-process=image/resize,m_lfit,h_1000,w_1000/format,jpg',
        subTitle: '眉妆',
        type: 1,
        subContent: [
          {
            title: '品项:',
            content: '多维点染眉⽴体野⽣眉 绒⽑织补术 ⽑发还原术 ⾯部磁场能量数字调整。'
          },
          {
            title: '特⾊:',
            content: '解决⾏业变⾊，晕⾊，脱⾊等症状。结合⽑发投影原理，做深度⽑发还原，给⽪肤进⾏播⾊，达到半⽶以外，不辨真假的仿真效果。'
          },
          {
            title: '后期不变⾊，不晕⾊，不掉⾊的神奇技艺。'
          }
        ]
      },
      {
        type: 2,
        img: 'https://ipxcdn.jfshare.com/ipxmall/856f3dbe3c2c294bd9dcb9d9384ee9ea'
      },
      {
        type: 2,
        img: 'https://ipxcdn.jfshare.com/ipxmall/d13bfe921785381cd3dd024b617d88ae'
      },
      {
        type: 2,
        img: 'https://ipxcdn.jfshare.com/ipxmall/674a71a1f23238d778fe31932d38f856'
      }
    ]
  }
]