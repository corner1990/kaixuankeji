export default {
  navigationBarTitleText: ''
}
