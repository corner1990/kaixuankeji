export const ADD = 'add'
export const MINUS = 'minus'
export const SETTAB = 'settab'