export default {
  pages: [
    'pages/index/index',
    'pages/teacherInfo/index',
    'pages/subscribe/index',
    'pages/collection/index',
    'pages/articleDetail/index',
    'pages/orderList/index',
    'pages/found/index',
    'pages/my/index',
    'pages/list/index',
    'pages/starTeacher/index',
  ],
  window: {
    navigationStyle: 'custom',
  }
}
